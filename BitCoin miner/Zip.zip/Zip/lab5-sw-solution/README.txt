The main project is in lab6.
lab6-bsp and lab6-hps are automatically generated from the microblaze template with the Xilinx SDK tools.

In order to use the bsp, the Microblaze core must be configured with exactly: 32KB RAM, external IO interface, GPI1&GPO1, FIT1.

If other settings are used, the BSP must be regenerated.
